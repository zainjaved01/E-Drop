@extends('dashboard')
@section('main-section')
    <section class="Mdetail-Wrapper">
        <div class="container">
            <h2 class="mb-">My Documents</h2>
            @foreach ($documents as $document)
                <div class="list-group-item">
                    <a href="{{ route('document.show', ['id' => $document->id]) }}"><i
                            class="fas fa-file-pdf  me-2"></i>{{ $document->title }}</a>
                    <a href="{{ route('document.edit', ['id' => $document->id]) }}">
                        <span style="margin:10px;font-size:12px"><i class="fas fa-pen  me-2"></i></span>
                    </a>
                </div>
            @endforeach
        </div>
    </section>
@endsection('main-section')
