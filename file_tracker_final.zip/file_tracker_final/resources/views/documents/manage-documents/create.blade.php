@extends('dashboard')
@section('main-section')
    <div>
        <form action="{{ route('document.store') }}" class=" m-auto w-75" method="post" enctype="multipart/form-data">
            <div>
                <h1 class="text-center my-5">Start New Document</h1>
                <div class="mb-3">
                    <input type="text" class="form-control" id="tdb" placeholder="Title of Document" name="title"
                        required>
                </div>
                @csrf
                <div class="mb-3">
                    <textarea type="text" class="form-control" id="tt" placeholder="Description or brief information for document"
                        name="description" required></textarea>
                    <div class="valid-feedback">Valid.</div>
                </div>
                <div class="mb-3">
                    <input type="file" class="form-control" id="tdb" name="file" placeholder="Title of Document"
                        name="tdb">
                </div>
                <div>
                    <p class="mb-1 mt-4"> Forword document to </p>
                    <div class="mb-2">
                        <label class="mr-3">
                            <input type="radio" name="targetType" value="user" checked>
                            User
                        </label>
                        <label class="mx-3">
                            <input type="radio" name="targetType" value="team">
                            Team
                        </label>
                    </div>
                    <div id="team-input" style="display:none">
                        <label>
                            <select class="select2" name="team">
                                <option>Select Team</option>
                                @foreach ($teamUnits as $unit)
                                    <option value="{{ $unit->id }}">{{ $unit->name }}</option>
                                @endforeach
                            </select>
                        </label>
                    </div>
                    <div id="user-input">
                        <label>
                            <select class="select3" name="person">
                                <option>Select User</option>
                                @foreach ($userUnits as $unit)
                                    <option value="{{ $unit->id }}">{{ $unit->name }}</option>
                                @endforeach
                            </select>
                        </label>
                    </div>
                </div>
                <div class="mb-3">
                    <center>
                        <input type="submit" class="btn main-btn" value="Submit">
                    </center>
                </div>
            </div>
        </form>
    </div>

    <script>

        const teamInput = document.querySelector('#team-input');
        const userInput = document.querySelector('#user-input');

        document.querySelectorAll('input[name="targetType"]').forEach((radio) => {
            radio.addEventListener('change', () => {
                if (radio.value === 'team') {
                    teamInput.style.display = 'block';
                    userInput.style.display = 'none';
                } else if (radio.value === 'user') {
                    teamInput.style.display = 'none';
                    userInput.style.display = 'block';
                }
            });
        });
    </script>
@endsection('main-section')
