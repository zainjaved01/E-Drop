@extends('dashboard')
@section('main-section')
    <section class="Mdetail-Wrapper">
        <div class="row">
            <div class="col-8 ml-5">
                <button class="btn sm btn-primary edit-document" data-toggle="modal" data-target="#editModal">Act</button>
                <h3 class="my-5 text-danger">{{ $document->title }}</h3>
                <div class="mb-3 mx-4 px-3">
                    {!! $document->description !!}
                </div>
                @if ($document->file)
                    @if (str_ends_with($document->file, 'png') ||
                            str_ends_with($document->file, 'jpg') ||
                            str_ends_with($document->file, 'jpeg'))
                        <img src="{{ asset($document->file) }}" alt="Image">
                    @else
                        <iframe width="800px" height="500px"
                            src="{{ asset($document->file) }}" frameborder="0"></iframe>
                    @endif
                @endif
            </div>
            <div class="col-3 mr-2" style="max-height: 500px; overflow-y: scroll;">
                <h3>Document History</h3>
                @foreach ($document->DocumentHistories as $history)
                    @if ($history->action == 'Forward')
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary">{{ $history->previous->name }}</span> forwarded
                                {{ $document->title }} to @if ($history->team)
                                    {{ $history->team->name }}
                                @else
                                    {{ $history->next->name }}
                                @endif, <span
                                    class="text-dark">{{ date('F j, g:i a', strtotime($history->created_at)) }}</span>
                                <p class="pt-2">{{ $history->remarks }}</p>

                            </a>
                        </ul>
                    @elseif ($history->action == 'Complete')
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary">{{ $history->previous->name }}</span> marked
                                {{ $document->title }} as completed. <span
                                    class="text-dark">{{ date('F j, g:i a', strtotime($history->created_at)) }}</span>
                                <p class="pt-2">{{ $history->remarks }}</p>

                            </a>
                        </ul>
                    @elseif ($history->action == 'Duplicate')
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary">{{ $history->previous->name }}</span> marked
                                {{ $document->title }} as duplicate. <span
                                    class="text-dark">{{ date('F j, g:i a', strtotime($history->created_at)) }}</span>
                                <p class="pt-2">{{ $history->remarks }}</p>

                            </a>
                        </ul>
                    @elseif ($history->action == 'Decline')
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary">{{ $history->previous->name }}</span> declined
                                {{ $document->title }}. <span
                                    class="text-dark">{{ date('F j, g:i a', strtotime($history->created_at)) }}</span>
                                <p class="pt-2">{{ $history->remarks }}</p>

                            </a>
                        </ul>
                    @elseif ($history->action == 'Initiated')
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary">{{ $history->previous->name }}</span> initiated
                                {{ $document->title }}. <span
                                    class="text-dark">{{ date('F j, g:i a', strtotime($history->created_at)) }}</span>
                                <p class="pt-2">{{ $history->remarks }}</p>
                            </a>
                        </ul>
                    @endif
                @endforeach
            </div>
        </div>
    </section>
    <!-- Edit Form Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit document</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('manage-document.store') }}" method="post">
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <p id="document-name"></p>
                        </div>
                        <input type="text" id="document-id" value="{{ $document->id }}" name="documentId" hidden />
                        <div class="form-group">
                            <label for="document-remark">Remarks*</label>
                            <textarea name="remarks" class="form-control" id="document-remark" required rows="3"
                                placeholder="Enter description"></textarea>
                        </div>
                        <div id="forwad-to" style="">
                            <p class="mb-1 mt-4"> Forword document to </p>
                            <div class="mb-2">
                                <label class="mr-3">
                                    <input type="radio" name="targetType" value="user" checked>
                                    User
                                </label>
                                <label class="mx-3">
                                    <input type="radio" name="targetType" value="team">
                                    Team
                                </label>
                            </div>
                            <div id="team-input" style="display:none">
                                <label>
                                    <select class="select2" name="team">
                                        <option>Select Team</option>
                                        @foreach ($teamUnits as $unit)
                                            <option value="{{ $unit->id }}">{{ $unit->name }}</option>
                                        @endforeach
                                    </select>
                                </label>
                            </div>
                            <div id="user-input">
                                <label>
                                    <select class="select3" name="person">
                                        <option>Select User</option>
                                        @foreach ($userUnits as $unit)
                                            <option value="{{ $unit->id }}">{{ $unit->name }}</option>
                                        @endforeach
                                    </select>
                                </label>
                            </div>
                        </div>
                        <script>
                            const teamInput = document.querySelector('#team-input');
                            const userInput = document.querySelector('#user-input');
                            document.querySelectorAll('input[name="targetType"]').forEach((radio) => {
                                radio.addEventListener('change', () => {
                                    if (radio.value === 'team') {
                                        teamInput.style.display = 'block';
                                        userInput.style.display = 'none';
                                    } else if (radio.value === 'user') {
                                        teamInput.style.display = 'none';
                                        userInput.style.display = 'block';
                                    }
                                });
                            });
                        </script>
                    </div>
                    <div class="modal-footer">
                        <input class="btn btn-sm btn-success" type="submit" name="submit" value="Complete" />
                        <input class="btn btn-sm btn-primary" onclick="$('#forwad-to').show();" type="submit"
                            name="submit" value="Forward" />
                        <input class="btn btn-sm btn-warning" type="submit" name="submit" value="Duplicate" />
                        <input class="btn btn-sm btn-danger" type="submit" name="submit" value="Decline" />
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.edit-document').click(function() {
                // var documentName = $(this).closest('.document').data('document-name');
                // var documentId = $(this).closest('.document').data('document-id');
                // console.log(documentId);
                // $('#document-name').text(documentName);
                // $('#document-id').val(documentId);
            });
        });
    </script>
@endsection('main-section')
