@extends('dashboard')
@section('main-section')
    <section class="Mdetail-Wrapper">
        <div class="container">
            <h2 class="mb-">Manage Documents</h2>
            @foreach ($documents as $document)
                <div class="list-group-item document" data-document-id="{{ $document->document->id }}"
                    data-document-name="{{ $document->document->title }}">
                    <a href="{{ route('manage-document.show', ['id' => $document->document->id]) }}"><i
                            class="fas fa-file-pdf  me-2"></i>{{ $document->document->title }}
                    </a>
                    @if(!($document->team_id || $document->next_id))
                    <p style="font-size: 12px;" class="text-success">Broad cast document</p>
                    @endif
                </div>
            @endforeach
        </div>
    </section>
@endsection('main-section')
