@extends('dashboard')
@section('main-section')
    <section class="Mdetail-Wrapper mx-4 px-3">
        <h3 class="my-5 text-danger">{{ $document->title }}</h3>
        <div class="mb-3 mx-4 px-3">
            {!! $document->description !!}
        </div>
        @if ($document->file)
            @if (str_ends_with($document->file, 'png') ||
                    str_ends_with($document->file, 'jpg') ||
                    str_ends_with($document->file, 'jpeg'))
                <img src="{{ asset( $document->file) }}" alt="Image">
            @else
                <iframe width="800px" height="500px" src="{{ asset($document->file) }}"
                    frameborder="0"></iframe>
            @endif
        @endif
        <div class="mb-3 mx-4 px-3">
            <p class="text-center my-5"></p>
        </div>
        </div>
    </section>
@endsection('main-section')
