@extends('dashboard')
@section('main-section')
<section class="Mhistoy-Wrapper">
    <div class="container w-50 ">
        <div class="row  ">
            <div class="col-3  align-self-center "><i class="fa-solid fa-arrow-left"></i></div>
            <div class="col   text-left  align-self-center  ">
                <h1>Member History</h1>
            </div>
            <div>
                <div class="row ms-3">
                    <div class="col-5"> Name</div>
                    <div class="col-7">Admin</div>
                </div>
                <div class="row ms-3">
                    <div class="col-5">Name</div>
                    <div class="col">Admin</div>
                    <div class="col "><a class="text-decoration-none" href=""> View Profile</a></div>
                </div>
                <div class=" row mt-3">
                    <div class="col text-bold">Notification innitiated:</div>
                </div>
                <div class="row mt-5 ">
                    <div class="col offset-2 ">
                        <ul class="list-group  ">
                            <li class="list-group-item border-0 ps-5 "> <i class='fas fa-file-pdf me-2'></i> Summer
                                Holidays Notification 2022</li>
                            <li class="list-group-item border-0  ps-5"> <i class='fas fa-file-pdf me-2'></i>Industrial
                                Tour Mechnical 2019</li>
                        </ul>
                    </div>
                </div>
            </div>
</section>
@endsection('main-section')