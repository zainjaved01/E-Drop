@extends('dashboard')
@section('main-section')
    <!--Section Search  Staff Members-->
    <section class=" smm-wrapper">
        <div class="notification-Wrapper">
            <div class="container  ">
                <div class="row  ">
                    <div class="col   text-left  align-self-center  ">
                        <h1>Search/Manage units</h1>
                    </div>
                </div>
                {{-- <form action="" class="mt-2">
                    <input type="text" name="" placeholder="Enter Name/ID/Destination....">
                    <button type="submit"><i class="fa-solid fa-magnifying-glass "></i></button>
                </form> --}}
            </div>
            <div class="container">
                <a class="list-group-item list-group-item-action border-0" style="margin-left: 80px" href="/units"><i
                    class="fa fa-sitemap fa-xl fa-xl"></i><span> Use Graph</span></a>
                <div class="row  mt-4">
                    @foreach ($units as $unit)
                        <div class="col-md-6 mb-4 d-flex justify-content-center">
                            <a href="{{ route('manage-unit', [ 'id' => $unit->id ]) }}">
                            <div class="card" style="">
                                <div class="card-body">
                                    <div class="row d-flex justify-content-center align-items-center mt-3 text-center">
                                        <div class="col text-start">{{ $unit->name }} <br> {{ $unit->type }}</div>
                                        <div class="col"> <i class="fa-solid fa-user"></i></div>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                    @endforeach
                </div>

            </div>
        </div>

    </section>
    <!--secton Search  Staff Members end-->
@endsection('main-section')
