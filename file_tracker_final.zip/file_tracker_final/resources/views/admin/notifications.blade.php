@extends('dashboard')
@section('main-section')
    <style>
        .list-group-item {
            border: 0;
        }
    </style>
    <section class=" notification-Wrapper">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <h1> Notifications</h1>
                </div>
            </div>
        </div>
        </div>
        <div class="container mt-4 ">
            <div class="row mt-3 ">
                @foreach ($notifications as $notification)
                    <div class="mx-3">
                        @if ($notification->action == 'Forward')
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary">{{ $notification->previous->name }}</span>
                                    forwarded {{ $notification->document->title }} to @if($notification->team)
                                        {{ $notification->team->name }} @else
                                        {{ $notification->next->name }}
                                    @endif, <span
                                        class="text-dark">{{ date('F j, g:i a', strtotime($notification->created_at)) }}</span></a>
                            </ul>
                            @elseif ($notification->action == 'Complete')
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary">{{ $notification->previous->name }}</span>
                                    marked {{ $notification->document->title }} as completed. <span
                                        class="text-dark">{{ date('F j, g:i a', strtotime($notification->created_at)) }}</span></a>
                            </ul>
                            @elseif ($notification->action == 'Duplicate')
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary">{{ $notification->previous->name }}</span>
                                    marked {{ $notification->document->title }} as duplicate. <span
                                        class="text-dark">{{ date('F j, g:i a', strtotime($notification->created_at)) }}</span></a>
                            </ul>
                            @elseif ($notification->action == 'Decline')
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary">{{ $notification->previous->name }}</span>
                                    declined {{ $notification->document->title }}. <span
                                        class="text-dark">{{ date('F j, g:i a', strtotime($notification->created_at)) }}</span></a>
                            </ul>
                            @elseif ($notification->action == 'Initiated')
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary">{{ $notification->previous->name }}</span>
                                        initiated {{ $notification->document->title }}. <span
                                        class="text-dark">{{ date('F j, g:i a', strtotime($notification->created_at)) }}</span></a>
                            </ul>
                        @endif
                    </div>
                @endforeach
            </div>
        </div>
    </section>
@endsection('main-section')
