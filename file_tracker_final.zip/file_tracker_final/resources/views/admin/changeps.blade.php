@extends('dashboard')
@section('main-section')
    <style>
        input[type="text"] {
            border: 4px #A32727;
        }
    </style>
    <!--Section Search  Staff Members-->
    <section class="password-Wrapper">

        <div class="">
            <div class="container pw ">
                <div class="row  ">
                    <div class="col-3  align-self-center "><i class="fa-solid fa-arrow-left"></i></div>
                    <div class="col   text-left  align-self-center  ">
                        <h1>Changed Password</h1>
                    </div>
                </div>
                <form class="mt-5  " action="/action_page.php">
                    <div class="mb-4 d-flex justify-content-center  ">

                        <input type="password" class="form-control   " id="formGroupExampleInput"
                            placeholder="Old password">
                    </div>
                    <div class="mb-4 d-flex justify-content-center">

                        <input type="password" class="form-control  " id="formGroupExampleInput2"
                            placeholder="New password">
                    </div>
                    <div class="mb-4 d-flex justify-content-center">

                        <input type="password" class="form-control  " id="formGroupExampleInput2"
                            placeholder="Re-Enter New Password">
                    </div>

                    <div class=" container mb-3 text-center">
                        <input class="form-check-input " type="checkbox" id="myCheck" name="remember" required>
                        <label class="form-check-label" for="myCheck">Show Password</label>

                    </div>
                    <div class="text-center">
                        <a href="Home.html" class="btn main-btn " role="button" aria-pressed="true">Long IN</a>

                    </div>
                </form>
            </div>
            </div>
    </section>
    <!--secton Search  Staff Members end-->
@endsection('main-section')
