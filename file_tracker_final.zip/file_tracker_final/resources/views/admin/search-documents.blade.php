@extends('dashboard')
@section('main-section')
    <!--Section Search  Staff Members-->
    <section class=" search-Wrapper mmt">
        <div class="container sw">
            <div class="row">
                <div class="col   text-left  align-self-center  ">
                    <h1>Search Document</h1>
                </div>
            </div>
            <form action="" method="get" class="mt-2">
                <input type="text" name="q" value="{{ $q ? $q : '' }}" placeholder="Document title keywords">
                <button type="submit"><i class="fa-solid fa-magnifying-glass "></i></button>
            </form>
            <div class="row">
                @if ($documents)
                <div class="col ml-3 mt-5" >
                    <p>Results:</p>
                    <ul class="list-group  ">
                        @foreach ($documents as $document)
                        <a href="{{ route('document.show', ['id' => $document->document->id]) }}"  class="list-group-item"><i class="fas fa-file-pdf me-2" ></i>{{ $document->document->title }}</a></ul>
                        @endforeach                       
                </div>
        
                @endif
      </div>
        </div>
    </section>
    <!--secton Search  Staff Members end-->
@endsection('main-section')
