@extends('base')
@section('navbar')
    <section class="header">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand text-white" href="/"><img style="32px;width:32px" src="{{ asset('images/logo.jpg') }}"/><span>  </span></a>
                <div class="d-flex d-block align-items-start">
                    <span class="align-self-center"><i class="fa-solid fa-circle-user fa-2xl"></i></span>
                    <span class="align-self-center ps-4 text-white">{{ auth()->user()->name }}</span>
                </div>


                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="/"><i class="fa-solid fa-house fa-xl "></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('manage-document.index') }}"><i
                                    class="fa-solid fa-inbox fa-xl"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('notifications') }}"><i
                                    class="fa-solid fa-bell fa-xl"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('search-documents') }}"><i
                                    class="fa-solid fa-magnifying-glass fa-xl"></i></a>
                        </li>
                        @if (auth()->user()->teams->count() > 0)
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa-solid fa-users fa-xl"></i>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item">{{ auth()->user()->currentTeam->name }}</a>
                                <hr class="my-1">
                                @foreach (auth()->user()->teams as $team)
                                    <a class="dropdown-item"
                                        href="{{ route('switch-team', ['id' => $team->id]) }}">{{ $team->name }}</a>
                                @endforeach
                            </div>
                        </li>
                        @endif
                        <li class="nav-item">
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <a class="nav-link">
                                    <button type="submit"
                                        class="fa-sharp fa-solid fa-right-from-bracket fa-xl text-light"></button>
                                </a>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <!--Navbar Section end-->
@endsection('navbar')
