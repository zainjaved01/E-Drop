@extends('base')
    @section('main-section')
    <section class="main">
        <div class="container mlogin ">
            <div class="row justify-content-center align-items-center ">
                <div class=" col-md-6">
                    <img src="images/logohd.jpg" class="img-fluid x-4" alt="">
                </div>
                <div class=" col-md-6">
                    <div class="form-info mt-5">
                        <h1 class="text-center">Log in</h1>
                        <p class="text-center"> Signin with your existing account.</p>
                    </div>
                    <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <div class="mb-4 d-flex justify-content-center">
                        <input type="email" class="form-control w-75" id="formGroupExampleInput"
                            placeholder="Email"
                            name="email"
                            value="{{ old('email') }}"
                            >
                    </div>


                    <div class="mb-4 d-flex justify-content-center">
                        <input class="form-control w-75 " id="formGroupExampleInput2"
                                type="password"
                                name="password"
                                required autocomplete="current-password">
                    </div>
                    @error('email')
<center>
    <p class="text-danger">{{ $message }}</p>
</center>
@enderror
                    @error('password')
                    <center>
                        <p class="text-danger222">{{ $message }}</p>
                    </center>@enderror
                <div class="mb-4 d-flex justify-content-center">
                    <button class="btn main-btn" role="button" type="submit" aria-pressed="true">LogIn</button>
                </div>

                <div class="mb-4 d-flex justify-content-center">
                    @if (Route::has('register'))
                        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('register') }}">
                            {{ __('Signup for new account') }}
                        </a>
                    @endif
                </div>

                <div class="mb-4 d-flex justify-content-center">
                    @if (Route::has('password.request'))
                        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('password.request') }}">
                            {{ __('Forgot your password?') }}
                        </a>
                    @endif
                </div>

            </form>
            </div>
        </div>
    </div>
</section>
@endsection('main-section')