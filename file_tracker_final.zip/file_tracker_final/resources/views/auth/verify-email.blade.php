@extends('base')
@section('main-section')
    <section class="main">
        <div class="container mlogin ">
            <div class="row justify-content-center align-items-center ">
                <div class=" col-md-6">
                    <img src="images/logohd.jpg" class="img-fluid x-4" alt="">
                </div>
                <div class=" col-md-6">
                    <div class="form-info mt-5">
                        <p class="text-center"> Update your account password</p>
                    </div>
                    <div class="mb-4 text-sm text-gray-600">
                        {{ __('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.') }}
                    </div>

                    @if (session('status') == 'verification-link-sent')
                        <div class="mb-4 font-medium text-sm text-green-600">
                            {{ __('A new verification link has been sent to the email address you provided during registration.') }}
                        </div>
                    @endif

                    <div class="mt-4 flex items-center justify-between">
                        <form method="POST" action="{{ route('verification.send') }}">
                            @csrf
                            <div>
                                <div class="mb-4 d-flex justify-content-center">
                                    <button class="btn main-btn" role="button" type="submit" aria-pressed="true">
                                        Resend Verification Email</button>
                                </div>

                            </div>
                        </form>

                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <div class="mb-4 d-flex justify-content-center">
                                <button class="btn main-btn" role="button" type="submit" aria-pressed="true">
                                    Log Out</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </section>
@endsection('main-section')

<x-guest-layout>
    <x-auth-card>
        <x-slot name="logo">
            <a href="/">
                <x-application-logo class="w-20 h-20 fill-current text-gray-500" />
            </a>
        </x-slot>

        <div class="mb-4 text-sm text-gray-600">
            {{ __('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.') }}
        </div>

        @if (session('status') == 'verification-link-sent')
            <div class="mb-4 font-medium text-sm text-green-600">
                {{ __('A new verification link has been sent to the email address you provided during registration.') }}
            </div>
        @endif

        <div class="mt-4 flex items-center justify-between">
            <form method="POST" action="{{ route('verification.send') }}">
                @csrf

                <div>
                    <x-button>
                        {{ __('Resend Verification Email') }}
                    </x-button>
                </div>
            </form>

            <form method="POST" action="{{ route('logout') }}">
                @csrf

                <button type="submit" class="underline text-sm text-gray-600 hover:text-gray-900">
                    {{ __('Log Out') }}
                </button>
            </form>
        </div>
    </x-auth-card>
</x-guest-layout>
