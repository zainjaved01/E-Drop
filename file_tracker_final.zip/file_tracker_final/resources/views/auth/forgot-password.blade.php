@extends('base')
    @section('main-section')
    <section class="main">
        <div class="container mlogin ">
            <div class="row justify-content-center align-items-center ">
                <div class=" col-md-6">
                    <img src="images/logohd.jpg" class="img-fluid x-4" alt="">
                </div>
                <div class=" col-md-6">
                    <div class="form-info mt-5">
                        <p class="text-center">Reset password</p>
                    </div>
                    <form method="POST" action="{{ route('password.email') }}">
                        @csrf
            
                    <div class="mb-4 d-flex justify-content-center">
                        <input type="email" class="form-control w-75" id="formGroupExampleInput"
                            placeholder="Email"
                            name="email"
                            value="{{ old('email') }}"
                            >
                    </div>
                <div class="mb-4 d-flex justify-content-center">
                    <button class="btn main-btn" role="button" type="submit" aria-pressed="true">Send Reset Link</button>
                </div>
                <div class="mb-4 d-flex justify-content-center">
                    @if (Route::has('password.request'))
                        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('login') }}">
                            {{ __('Login to your account') }}
                        </a>
                    @endif
                </div>


            </form>
            </div>
        </div>
    </div>
</section>
@endsection('main-section')
