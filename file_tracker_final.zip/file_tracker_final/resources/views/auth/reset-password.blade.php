@extends('base')
@section('main-section')
    <section class="main">
        <div class="container mlogin ">
            <div class="row justify-content-center align-items-center ">
                <div class=" col-md-6">
                    <img src="images/logohd.jpg" class="img-fluid x-4" alt="">
                </div>
                <div class=" col-md-6">
                    <div class="form-info mt-5">
                        <h1 class="text-center mb-4">Reset Password</h1>
                        <p class="text-center"> Update your account password</p>
                    </div>
                    <form method="POST" action="{{ route('password.update') }}">
                        @csrf

                        <input type="hidden" name="token" value="{{ $request->route('token') }}">

                        <div class="mb-4 d-flex justify-content-center">
                            <input type="email" class="form-control w-75" id="formGroupExampleInput" placeholder="Email"
                                name="email" value="{{ old('email', $request->email) }}">
                        </div>

                        <div class="mb-4 d-flex justify-content-center">
                            <input class="form-control w-75 " id="formGroupExampleInput2" placeholder="New password"
                                type="password" name="password" required autocomplete="current-password">
                        </div>
                        <div class="mb-4 d-flex justify-content-center">
                            <input class="form-control w-75 " id="formGroupExampleInput2" placeholder="Confirm password"
                                type="password" name="password_confirmation" required autocomplete="current-password">
                        </div>

                        <div class="mb-4 d-flex justify-content-center">
                            <button class="btn main-btn" role="button" type="submit" aria-pressed="true">Reset
                                Password</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </section>
@endsection('main-section')
