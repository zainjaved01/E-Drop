<?php

use App\Http\Controllers\Org\UnitController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\ManageDocumentController;
use App\Models\DocumentHistory;
use App\Models\Unit;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Team;
use Mpociot\Teamwork\Exceptions\UserNotInTeamException;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;

/*
1|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('/units', UnitController::class);
Route::post('/units/{id}', [UnitController::class, 'update'])->name('unit-update');
Route::delete('/units/{id}', [UnitController::class, 'deleteUnit']);

Route::group(['middleware' => ['auth']], function () {
    Route::get('documents', [DocumentController::class, 'index'])->name('document.index');
    Route::get('document/{id}', [DocumentController::class, 'show'])->name('document.show');
    Route::get('create-document', [DocumentController::class, 'create'])->name('document.create');
    Route::post('create-document/store', [DocumentController::class, 'store'])->name('document.store');
    Route::get('edit-document/{id}', [DocumentController::class, 'edit'])->name('document.edit');
    Route::post('edit-document/{id}/update', [DocumentController::class, 'update'])->name('document.update');
});

Route::group(['middleware' => ['auth']], function () {
    Route::get('manage-documents', [ManageDocumentController::class, 'index'])->name('manage-document.index');
    Route::get('manage-documents/{id}', [ManageDocumentController::class, 'show'])->name('manage-document.show');
    Route::post('manage-document/manage', [ManageDocumentController::class, 'store'])->name('manage-document.store');
});

Route::get('switch-team/{id}', function ($id) {
    $team = Team::findOrFail($id);
    try {
        auth()->user()->switchTeam($team);
    } catch (UserNotInTeamException $e) {
        abort(403);
    }
    return redirect()->back();
})
    ->middleware(['auth'])->name('switch-team');

Route::get('/', function () {
    $teamUnit = null;
    if (auth()->user()->currentTeam) {
        $teamUnit = Unit::where('team_id', auth()->user()->currentTeam->id)->first();
    }
    return view('admin.home', compact('teamUnit'));
})
    ->middleware(['auth'])->name('index');

Route::get('/search-documents', function () {
    $q = request()->input('q');
    $user = auth()->user();
    $documents = null;
    if ($q) {
        $documents = DocumentHistory::with('document');
        if (!($user->isSuperAdmin())) {
            $documents = $documents->where('next_id', $user->id)
                ->orWhere('previous_id', $user->id);
            if ($user->currentTeam) {
                $documents = $documents->orWhere('team_id', $user->currentTeam->id);
            }
        }
        $documents = $documents->whereHas('document', function ($query) use ($q) {
            $query->where('title', 'LIKE', '%' . $q . '%')
                ->whereRaw('LOWER(title) COLLATE utf8mb4_unicode_ci LIKE ?', ['%' . strtolower($q) . '%']);
        })
            ->get();
    }
    return view('admin.search-documents', compact('q', 'documents'));
})->name('search-documents');

Route::get('/access-member', function () {
    return view('admin.AccessMember');
})->name('access-member');

Route::get('/manage-units', function () {
    $units = Unit::with('team')->get();
    return view('admin.manage-units', compact('units'));
})->name('manage-units');

Route::get('/manage-unit/{id}', function ($id) {
    $unit = Unit::with(['parent', 'children', 'responder'])->find($id);
    $userUnits = User::all();
    return view('admin.manage-unit', compact('unit', 'userUnits'));
})->name('manage-unit');

Route::post('/manage-unit/{id}', function ($id) {
    $unit = Unit::with(['parent', 'children', 'responder'])->find($id);
    if (request()->input('choose')) {
        $user = User::find(request()->input('user_id'));
        $user->attachTeam($unit->team_id);
        $unit->responder_id = $user->id;
        $unit->save();
    }

    if (request()->input('create')) {
        try {
            $request = request();
            $user = User::where('email', $request->semail)->first();
            if (is_null($user) && ($request->username && $request->email && $request->password)) {
                $user = User::create(
                    [
                        'name' => $request->username,
                        'email' => $request->email,
                        'password' => Hash::make($request->password),
                    ]
                );
            }
            $user->attachTeam($unit->team_id);
        } catch (Exception $e) {
        }
    }
    return redirect()->back();
})->name('manage-unit');

Route::get('/notifications', function () {
    $notifications = DocumentHistory::where(function ($query) {
        $query->where('previous_id', auth()->user()->id)
            ->orWhere('next_id', auth()->user()->id)
            ->orWhereHas('document', function ($query) {
                $query->where('user_id', auth()->user()->id);
            });
    });

    if (auth()->user()->currentTeam) {
        $notifications = $notifications->orWhereHas('document', function ($query) {
            $query->where('team_id', auth()->user()->currentTeam->id);
        });
    }

    $notifications = $notifications->orWhere(function ($query) {
        $query->whereNull('team_id')->whereNull('next_id');
    });

    $notifications = $notifications->latest('created_at')->get();
    return view('admin.notifications', compact('notifications'));
})->name('notifications');



require __DIR__ . '/auth.php';
