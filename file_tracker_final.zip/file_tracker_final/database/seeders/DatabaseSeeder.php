<?php

namespace Database\Seeders;

use \App\Models\User;
use \App\Models\Team;
use \App\Models\Unit;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $password = Hash::make('secret');

        $user = User::create([
            'name' => "user",
            'email' => 'user@nfciet.edu.pk',
            'password' => $password,
        ]);

        $user = User::create([
            'name' => "Vice Chanceller",
            'email' => 'vc@nfciet.edu.pk',
            'password' => $password,
        ]);
        Unit::create([
            'name' => 'VC - SuperAdmin',
            'pid' => null,
            'type' => 'user',
            'user_id' => $user->id,
            'team_id' => null,
        ]);

        $teams = [
            [
                'owner' => [
                    'name' => 'Naeem Aslam',
                    'email' => 'naeemaslam@nfciet.edu.pk',
                    'password' => $password
                ],
                'responder' => [
                    'name' => 'Imran Altaf',
                    'email' => 'imranaltaf@nfciet.edu.pk',
                    'password' => $password
                ],
                'team' => 'CS Department',
                'pid' => 1,
            ],
            [
                'owner' => [
                    'name' => 'Naeem Aslam',
                    'email' => 'naeemaslam@nfciet.edu.pk',
                    'password' => $password
                ],
                'team' => 'SE Department',
                'pid' => 1,
            ],
            [
                'owner' => [
                    'name' => 'Naeem Aslam',
                    'email' => 'naeemaslam@nfciet.edu.pk',
                    'password' => $password
                ],
                'team' => 'IT Department',
                'pid' => 1,
            ],
            [
                'owner' => [
                    'name' => 'Muhammad Maghfoor Anwar',
                    'email' => 'maghfooranwar@nfciet.edu.pk',
                    'password' => $password
                ],
                'team' => 'Finance',
                'pid' => 1,
            ],
        ];

        foreach ($teams as $team) {
            $user = User::firstOrCreate([
                'name' => $team['owner']['name'],
                'email' => $team['owner']['email'],
                'password' => $team['owner']['password'],
            ]);
            
            $teamObj = Team::create([
                'name' => $team['team'],
                'owner_id' => $user->id
            ]);

            $user->attachTeam($teamObj);

            if(isset($team['responder'])){
                $responder = User::firstOrCreate([
                    'name' => $team['responder']['name'],
                    'email' => $team['responder']['email'],
                    'password' => $team['responder']['password'],
                ]);
                $responder->attachTeam($teamObj);

            }
            
            Unit::create([
                'name' => $team['team'],
                'pid' => $team['pid'],
                'type' => 'team',
                'user_id' => $user->id,
                'responder_id' => $responder ? $responder->id : null,
                'team_id' => $teamObj->id,
            ]);
        }
    }
}
