<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDocumentHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('document_histories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('document_id')->nullable();
            $table->unsignedBigInteger('next_id')->nullable();
            $table->unsignedInteger('team_id')->nullable();
            $table->unsignedBigInteger('previous_id');
            $table->enum('action', ['Initiated', 'Decline', 'Complete', 'Forward', 'Duplicate'])->default('Initiated');
            $table->text('remarks')->nullable();
            $table->foreign('document_id')->references('id')->on('documents')->onDelete('cascade');
            $table->foreign('team_id')->references('id')->on('teams')->onDelete('cascade');
            $table->foreign('next_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('previous_id')->references('id')->on('users')->onDelete('cascade');
            $table->boolean('responded')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('document_histories');
    }
}
