    <?php $__env->startSection('main-section'); ?>
    <section class="main">
        <div class="container mlogin ">
            <div class="row justify-content-center align-items-center ">
                <div class=" col-md-6">
                    <img src="images/logohd.jpg" class="img-fluid x-4" alt="">
                </div>
                <div class=" col-md-6">
                    <div class="form-info mt-5">
                        <h1 class="text-center">Log in</h1>
                        <p class="text-center"> Signin with your existing account.</p>
                    </div>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-4 d-flex justify-content-center">
                        <input type="email" class="form-control w-75" id="formGroupExampleInput"
                            placeholder="Email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            >
                    </div>


                    <div class="mb-4 d-flex justify-content-center">
                        <input class="form-control w-75 " id="formGroupExampleInput2"
                                type="password"
                                name="password"
                                required autocomplete="current-password">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<center>
    <p class="text-danger"><?php echo e($message); ?></p>
</center>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <center>
                        <p class="text-danger222"><?php echo e($message); ?></p>
                    </center><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-4 d-flex justify-content-center">
                    <button class="btn main-btn" role="button" type="submit" aria-pressed="true">LogIn</button>
                </div>

                <div class="mb-4 d-flex justify-content-center">
                    <?php if(Route::has('register')): ?>
                        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('register')); ?>">
                            <?php echo e(__('Signup for new account')); ?>

                        </a>
                    <?php endif; ?>
                </div>

                <div class="mb-4 d-flex justify-content-center">
                    <?php if(Route::has('password.request')): ?>
                        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot your password?')); ?>

                        </a>
                    <?php endif; ?>
                </div>

            </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hamid\Documents\University\FYP\file_tracker_Fullnfinal\file_tracker_final\resources\views/auth/login.blade.php ENDPATH**/ ?>