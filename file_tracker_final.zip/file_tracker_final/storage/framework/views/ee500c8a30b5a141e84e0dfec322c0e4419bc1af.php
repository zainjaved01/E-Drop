<?php $__env->startSection('navbar'); ?>
    <section class="header">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand text-white" href="/"><img style="32px;width:32px" src="<?php echo e(asset('images/logo.jpg')); ?>"/><span>  </span></a>
                <div class="d-flex d-block align-items-start">
                    <span class="align-self-center"><i class="fa-solid fa-circle-user fa-2xl"></i></span>
                    <span class="align-self-center ps-4 text-white"><?php echo e(auth()->user()->name); ?></span>
                </div>


                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="/"><i class="fa-solid fa-house fa-xl "></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('manage-document.index')); ?>"><i
                                    class="fa-solid fa-inbox fa-xl"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('notifications')); ?>"><i
                                    class="fa-solid fa-bell fa-xl"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('search-documents')); ?>"><i
                                    class="fa-solid fa-magnifying-glass fa-xl"></i></a>
                        </li>
                        <?php if(auth()->user()->teams->count() > 0): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa-solid fa-users fa-xl"></i>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item"><?php echo e(auth()->user()->currentTeam->name); ?></a>
                                <hr class="my-1">
                                <?php $__currentLoopData = auth()->user()->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item"
                                        href="<?php echo e(route('switch-team', ['id' => $team->id])); ?>"><?php echo e($team->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <a class="nav-link">
                                    <button type="submit"
                                        class="fa-sharp fa-solid fa-right-from-bracket fa-xl text-light"></button>
                                </a>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <!--Navbar Section end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/dashboard.blade.php ENDPATH**/ ?>