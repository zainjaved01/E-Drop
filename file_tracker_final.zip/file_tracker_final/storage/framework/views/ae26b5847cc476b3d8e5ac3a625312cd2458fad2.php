    <?php $__env->startSection('main-section'); ?>
    <section class="main">
        <div class="container mlogin ">
            <div class="row justify-content-center align-items-center ">
                <div class=" col-md-6">
                    <img src="images/logohd.jpg" class="img-fluid x-4" alt="">
                </div>
                <div class=" col-md-6">
                    <div class="form-info mt-5">
                        <p class="text-center">Reset password</p>
                    </div>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
            
                    <div class="mb-4 d-flex justify-content-center">
                        <input type="email" class="form-control w-75" id="formGroupExampleInput"
                            placeholder="Email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            >
                    </div>
                <div class="mb-4 d-flex justify-content-center">
                    <button class="btn main-btn" role="button" type="submit" aria-pressed="true">Send Reset Link</button>
                </div>
                <div class="mb-4 d-flex justify-content-center">
                    <?php if(Route::has('password.request')): ?>
                        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('login')); ?>">
                            <?php echo e(__('Login to your account')); ?>

                        </a>
                    <?php endif; ?>
                </div>


            </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hamid\Documents\University\FYP\file_tracker_Fullnfinal\file_tracker_final\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>