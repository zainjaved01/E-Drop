<?php $__env->startSection('main-section'); ?>
    <section class="Mdetail-Wrapper">
        <div class="row">
            <div class="col-8 ml-5">
                <button class="btn sm btn-primary edit-document" data-toggle="modal" data-target="#editModal">Act</button>
                <h3 class="my-5 text-danger"><?php echo e($document->title); ?></h3>
                <div class="mb-3 mx-4 px-3">
                    <?php echo $document->description; ?>

                </div>
                <?php if($document->file): ?>
                    <?php if(str_ends_with($document->file, 'png') ||
                            str_ends_with($document->file, 'jpg') ||
                            str_ends_with($document->file, 'jpeg')): ?>
                        <img src="<?php echo e(asset($document->file)); ?>" alt="Image">
                    <?php else: ?>
                        <iframe width="800px" height="300px"
                            src="<?php echo e(asset($document->file)); ?>" frameborder="0"></iframe>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-3 mr-2" style="max-height: 500px; overflow-y: scroll;">
                <h3>Document History</h3>
                <?php $__currentLoopData = $document->DocumentHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($history->action == 'Forward'): ?>
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary"><?php echo e($history->previous->name); ?></span> forwarded
                                <?php echo e($document->title); ?> to <?php if($history->team): ?>
                                    <?php echo e($history->team->name); ?>

                                <?php else: ?>
                                    <?php echo e($history->next->name); ?>

                                <?php endif; ?>, <span
                                    class="text-dark"><?php echo e(date('F j, g:i a', strtotime($history->created_at))); ?></span>
                                <p class="pt-2"><?php echo e($history->remarks); ?></p>

                            </a>
                        </ul>
                    <?php elseif($history->action == 'Complete'): ?>
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary"><?php echo e($history->previous->name); ?></span> marked
                                <?php echo e($document->title); ?> as completed. <span
                                    class="text-dark"><?php echo e(date('F j, g:i a', strtotime($history->created_at))); ?></span>
                                <p class="pt-2"><?php echo e($history->remarks); ?></p>

                            </a>
                        </ul>
                    <?php elseif($history->action == 'Duplicate'): ?>
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary"><?php echo e($history->previous->name); ?></span> marked
                                <?php echo e($document->title); ?> as duplicate. <span
                                    class="text-dark"><?php echo e(date('F j, g:i a', strtotime($history->created_at))); ?></span>
                                <p class="pt-2"><?php echo e($history->remarks); ?></p>

                            </a>
                        </ul>
                    <?php elseif($history->action == 'Decline'): ?>
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary"><?php echo e($history->previous->name); ?></span> declined
                                <?php echo e($document->title); ?>. <span
                                    class="text-dark"><?php echo e(date('F j, g:i a', strtotime($history->created_at))); ?></span>
                                <p class="pt-2"><?php echo e($history->remarks); ?></p>

                            </a>
                        </ul>
                    <?php elseif($history->action == 'Initiated'): ?>
                        <ul class="list-group mb-1 pb-1">
                            <a class="list-group-item">
                                <i class="fas fa-file-pdf me-2"></i>
                                <span class="text-primary"><?php echo e($history->previous->name); ?></span> initiated
                                <?php echo e($document->title); ?>. <span
                                    class="text-dark"><?php echo e(date('F j, g:i a', strtotime($history->created_at))); ?></span>
                                <p class="pt-2"><?php echo e($history->remarks); ?></p>
                            </a>
                        </ul>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Edit Form Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit document</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('manage-document.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <p id="document-name"></p>
                        </div>
                        <input type="text" id="document-id" value="<?php echo e($document->id); ?>" name="documentId" hidden />
                        <div class="form-group">
                            <label for="document-remark">Remarks*</label>
                            <textarea name="remarks" class="form-control" id="document-remark" required rows="3"
                                placeholder="Enter description"></textarea>
                        </div>
                        <div id="forwad-to" style="">
                            <p class="mb-1 mt-4"> Forword document to </p>
                            <div class="mb-2">
                                <label class="mr-3">
                                    <input type="radio" name="targetType" value="user" checked>
                                    User
                                </label>
                                <label class="mx-3">
                                    <input type="radio" name="targetType" value="team">
                                    Team
                                </label>
                            </div>
                            <div id="team-input" style="display:none">
                                <label>
                                    <select class="select2" name="team">
                                        <option>Select Team</option>
                                        <?php $__currentLoopData = $teamUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                            <div id="user-input">
                                <label>
                                    <select class="select3" name="person">
                                        <option>Select User</option>
                                        <?php $__currentLoopData = $userUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <script>
                            const teamInput = document.querySelector('#team-input');
                            const userInput = document.querySelector('#user-input');
                            document.querySelectorAll('input[name="targetType"]').forEach((radio) => {
                                radio.addEventListener('change', () => {
                                    if (radio.value === 'team') {
                                        teamInput.style.display = 'block';
                                        userInput.style.display = 'none';
                                    } else if (radio.value === 'user') {
                                        teamInput.style.display = 'none';
                                        userInput.style.display = 'block';
                                    }
                                });
                            });
                        </script>
                    </div>
                    <div class="modal-footer">
                        <input class="btn btn-sm btn-success" type="submit" name="submit" value="Complete" />
                        <input class="btn btn-sm btn-primary" onclick="$('#forwad-to').show();" type="submit"
                            name="submit" value="Forward" />
                        <input class="btn btn-sm btn-warning" type="submit" name="submit" value="Duplicate" />
                        <input class="btn btn-sm btn-danger" type="submit" name="submit" value="Decline" />
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.edit-document').click(function() {
                // var documentName = $(this).closest('.document').data('document-name');
                // var documentId = $(this).closest('.document').data('document-id');
                // console.log(documentId);
                // $('#document-name').text(documentName);
                // $('#document-id').val(documentId);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker_final/resources/views/documents/manage-documents/show.blade.php ENDPATH**/ ?>