<?php $__env->startSection('main-section'); ?>
    <section class="Mdetail-Wrapper">
        <div class="container">
            <h2 class="mb-">My Documents</h2>
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item">
                    <a href="<?php echo e(route('document.show', ['id' => $document->id])); ?>"><i
                            class="fas fa-file-pdf  me-2"></i><?php echo e($document->title); ?></a>
                    <a href="<?php echo e(route('document.edit', ['id' => $document->id])); ?>">
                        <span style="margin:10px;font-size:12px"><i class="fas fa-pen  me-2"></i></span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker_final/resources/views/documents/index.blade.php ENDPATH**/ ?>