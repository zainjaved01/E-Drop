<?php $__env->startSection('main-section'); ?>
    <style>
        .hide {
            display: none;
        }
    </style>

    <section class="Mdetail-Wrapper">
        <div class="container mdr  ">
            <div class="row  ">
                <center>
                    <h1>Unit Details and Management</h1>
                </center>
                <div class="col text-md-start  align-self-center  ">
                </div>
                <div>
                    <div class="row mt-5">
                        <div class="col  ">
                            <ul class="list-group ">
                                <li class="list-group-item border-0 pt-3">Name: <?php echo e($unit->name); ?></li>
                                <li class="list-group-item border-0 pt-3">Type: <?php echo e($unit->type); ?></li>
                                <li class="list-group-item border-0 pt-3">Controller: <?php echo e($unit->user->name); ?></li>
                                <?php if($unit->team): ?>
                                    <li class="list-group-item border-0 pt-3">Team Members:
                                        <?php $__currentLoopData = $unit->team->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($member->name); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <span>
                                            <button class="btn m-2 btn-sm btn-primary" id="add-member">
                                                Add New Member
                                            </button>
                                    </li>
                                <?php endif; ?>
                                <?php if($unit->parent): ?>
                                <li class="list-group-item border-0 pt-3">Parent Unit: <?php echo e($unit->parent->name); ?></li>
                                <?php endif; ?>
                                <?php if($unit->children->count() > 0): ?>
                                    <li class="list-group-item border-0 pt-3">SubUnits: <?php $__currentLoopData = $unit->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($child->name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </div>
                        <div class="col">
                            <ul class="list-group">
                                <?php if($unit->team): ?>
                                    <li class="list-group-item border-0 pt-3">Responder:
                                        <?php echo e($unit->responder->name); ?><span><button class="btn m-2 btn-sm btn-primary"
                                                id="change-responder">Change</button></span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
    </section>

<?php if($unit->team): ?>
    <div id="change-responder-modal" class="modal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Set Default Responder</h2>
                </div>
                <div class="modal-body" id="ChoosefromTeamBody">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="choose" value="1" hidden>
                        <label for="node-name">Choosing a user for default responding:</label>
                        <select class="select2" name="user_id" id="type">
                            <option>Select user..</option>
                            <?php $__currentLoopData = $unit->team->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                onclick="$('#change-responder-modal').hide();">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="add-member-modal" class="modal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Add New Member in Unit Team</h2>
                </div>
                <div class="modal-body">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="create" value="1" hidden>
                        <div class="row pl-3 py-2">
                            <div class="form-check col-5">
                            <input class="form-check-input" type="radio" name="user-type" id="existing-user" value="existing" checked>
                            <label class="form-check-label" for="existing-user">
                                Only if user exist
                            </label>
                        </div>
                        <div class="form-check col-6">
                            <input class="form-check-input" type="radio" name="user-type" id="new-user" value="new">
                            <label class="form-check-label" for="new-user">
                                Create new if don't exist
                            </label>
                        </div>
                    </div>
                    <div id="select-user-form">
                        <label for="node-name">Select user:</label>
                        <select class="select2" name="semail" id="type">
                            <option>Select user..</option>
                            <?php $__currentLoopData = $userUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->email); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     </div>
                    <div id="new-user-form">
                        <label for="node-name">Email:</label>
                        <input type="email" class="form-control" id="node-name" name="email">        
                        <label for="node-name">User's Name</label>
                        <input type="text" class="form-control" id="node-name" name="username">
                        <label for="node-name">Password:</label>
                        <input type="password" class="form-control" id="node-name" name="password">
                    </div>
                    </div>
                    <script>
                        $(document).ready(function() {
                            $("#new-user-form").hide();
                            $("input[name='user-type']").change(function() {
                                if ($(this).val() === 'existing') {
                                    $("#new-user-form").hide();
                                    $("#select-user-form").show();
                                } else {
                                    $("#select-user-form").hide();
                                    $("#new-user-form").show();
                                }
                            });
                        });
                    </script>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                onclick="$('#add-member-modal').hide();">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#change-responder').on('click', function() {
                $('#change-responder-modal').show();
            });
        });
        $(document).ready(function() {
            $('#add-member').on('click', function() {
                $('#add-member-modal').show();
            });
        });
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/admin/manage-unit.blade.php ENDPATH**/ ?>