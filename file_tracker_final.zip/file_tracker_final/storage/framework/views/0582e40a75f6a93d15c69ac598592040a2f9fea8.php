<?php $__env->startSection('main-section'); ?>
    <!--Section Home-->
    <section class=" Home-Wrapper">
        <div class="container Hw">
            <h1 class="text-center">Home</h1>
            <div class="list-group text-center border-0 mt-5 ">
                <a class="list-group-item list-group-item-action border-0" href="<?php echo e(route('document.create')); ?>"><i
                        class="fa fa-plus-circle fa-xl"></i><span> New Document</span></a>
                <a href="<?php echo e(route('document.index')); ?>" class="list-group-item list-group-item-action border-0">
                    <i class="fas fa-clone fa-xl"></i><span> My
                        Documents</span>
                </a>
                <a class="list-group-item list-group-item-action border-0" href="<?php echo e(route('manage-document.index')); ?>"><i
                        class="fa-solid fa-inbox fa-xl"></i><span> Document Inbox</span></a>
                        <?php if($teamUnit && auth()->user()->currentTeam && auth()->user()->currentTeam->owner_id == auth()->user()->id): ?>
                        <a href="<?php echo e(route('manage-unit', [ 'id' => $teamUnit->id ])); ?>" class="list-group-item list-group-item-action border-0">
                            <i class="fa-solid fa-users fa-xl"></i>
                            <span>Manage Team</span>
                        </a>
                        <?php endif; ?>
                        <?php if(auth()->user()->isSuperAdmin()): ?>
                    <a href="<?php echo e(route('manage-units')); ?>" class="list-group-item list-group-item-action border-0">
                        <i class="fa fa-sitemap fa-xl"></i><span> Manage Units</span></a>
                <?php endif; ?>

            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker_final/resources/views/admin/home.blade.php ENDPATH**/ ?>