<?php $__env->startSection('main-section'); ?>
<style>
    .hide {
        display: none;
    }
</style>
<div id="add-node-modal" class="modal">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Node</h2>
            </div>
            <form id="add-node-form">
                <div class="modal-body">
                    <label for="node-name">Node Name:</label>
                    <input type="text" class="form-control" id="node-name" name="name">
                    <label for="node-name">Type:</label>
                    <select class="form-control" name="type" id="type">
                        <option value="user">User</option>
                        <option value="team">Team</option>
                    </select>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div id="team-div" class="col-12 hide">
                            <label for="node-name">Team Name</label>
                            <input type="text" class="form-control" id="node-name" name="team">
                        </div>
                    </div>
                    <div class="row pl-3 py-2">
                        <div class="form-check col-5">
                        <input class="form-check-input" type="radio" name="user-type" id="existing-user" value="existing" checked>
                        <label class="form-check-label" for="existing-user">
                            Only if user exist
                        </label>
                    </div>
                    <div class="form-check col-6">
                        <input class="form-check-input" type="radio" name="user-type" id="new-user" value="new">
                        <label class="form-check-label" for="new-user">
                            Create new if don't exist
                        </label>
                    </div>
                </div>
                <div id="select-user-form">
                    <label for="node-name">Select user:</label>
                    <select class="select2" name="semail" id="type">
                        <option>Select user..</option>
                        <?php $__currentLoopData = $userUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->email); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                <div id="new-user-form">
                    <label for="node-name">Email:</label>
                    <input type="email" class="form-control" id="node-name" name="email">        
                    <label for="node-name">User's Name</label>
                    <input type="text" class="form-control" id="node-name" name="username">
                    <label for="node-name">Password:</label>
                    <input type="password" class="form-control" id="node-name" name="password">
                </div>
                </div>
                <script>
                    $(document).ready(function() {
                        $("#new-user-form").hide();
                        $("input[name='user-type']").change(function() {
                            if ($(this).val() === 'existing') {
                                $("#new-user-form").hide();
                                $("#select-user-form").show();
                            } else {
                                $("#select-user-form").hide();
                                $("#new-user-form").show();
                            }
                        });
                    });
                </script>
                                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        onclick="$('#add-node-modal').hide();">Close</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="edit-node-modal" class="modal">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit this Node</h2>
            </div>
            <form id="add-node-form">
                <div class="modal-body">
                    <label for="node-name">Node Name:</label>
                    <input type="text" class="form-control" id="edit-node-name" name="name">
                    <label for="node-name">Type:</label>
                    <select class="form-control" name="type" id="edit-type">
                        <option value="user">User</option>
                        <option value="team">Team</option>
                    </select>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-6">
                            <label for="node-name">User's Name</label>
                            <input type="text" class="form-control" id="edit-user-name" name="username">
                        </div>
                        <div id="team-div" class="col-6 hide">
                            <label for="node-name">Team Name</label>
                            <input type="text" class="form-control" id="edit-team-name" name="team">
                        </div>
                    </div>
                    <label for="node-name">Email:</label>
                    <input type="email" class="form-control" id="edit-user-email" name="email">
                    <label for="node-name">Password:</label>
                    <input type="password" class="form-control" id="edit-user-password" name="password">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        onclick="$('#edit-node-modal').hide();">Close</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="delete-node-modal" class="modal">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Confirm Deletion</h2>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this node?</p>
            </div>
            <div class="modal-footer">
                <button id="delete-node-confirm" class="btn btn-danger" type="button">Delete</button>
                <button id="delete-node-cancel" class="btn btn-success" type="button">Cancel</button>
            </div>
        </div>
    </div>
</div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div id="tree">
    </div>
    <script>
        $(document).ready(function() {
            $('#type').on('change', function() {
                var selected = $(this).val();
                $('.hide').hide();
                $('#' + selected + '-div').show();
            });
        });
        var chart = new OrgChart(document.getElementById("tree"), {
            enableDragDrop: true,
            nodeMenu: {
                add: {
                    text: "Add"
                },
                // edit: {
                //     text: "Edit",
                //     onClick: function(nodeId) {
                //         var node = chart.get(nodeId);
                //         $('#edit-node-modal').show();
                //         document.getElementById("edit-node-name").value = node.name;
                //         document.getElementById("edit-type").value = node.type;
                //         document.getElementById("edit-team-name").value = node.team.name;
                //         document.getElementById("edit-user-name").value = node.user.name;
                //         document.getElementById("edit-user-email").value = node.user.email;
                //         document.getElementById("edit-user-password").value = null;
                //         $('#edit-node-form')
                //             .submit(function(event) {
                //                 event.preventDefault();
                //                 var formData = $(this).serializeArray();
                //                 if (node.pid) {
                //                     formData.push([
                //                     {
                //                         name: "pid",
                //                         value: parseInt(node.pid)
                //                     },
                //                     {
                //                         name: "id",
                //                         value: parseInt(node.pid)
                //                     }
                //                     ]);
                //                 }
                //                 $.ajax({
                //                     type: 'POST',
                //                     url: "<?php echo e(route('unit-update', ['id' => ':unit' ])); ?>",
                //                     data: formData,
                //                     success: function(data) {
                //                         location.reload();
                //                         sender.updateNode({
                //                             id: new Date().valueOf(),
                //                             pid: formData[1].value,
                //                             name: formData[0].value,
                //                         });
                //                         // $('#add-node-modal').hide();
                //                     }
                //                 });
                //             });
                //     }
                // },
                remove: {
                    text: "Remove"
                }
            },
            nodeBinding: {
                field_0: "name",
                field_1: "type",
            }
        });

        chart.on('add', function(sender, node) {
            $('#add-node-modal').show();
            $('#add-node-form').submit(function(event) {
                event.preventDefault();
                var formData = $(this).serializeArray();
                if (node.pid) {
                    formData.push({
                        name: "pid",
                        value: parseInt(node.pid)
                    });
                }
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(route('units.store')); ?>",
                    data: formData,
                    success: function(data) {
                        location.reload();
                        sender.updateNode({
                            id: new Date().valueOf(),
                            pid: formData[1].value,
                            name: formData[0].value,
                        });
                        $('#add-node-modal').hide();
                    }
                });
            });
        });

        chart.on('remove', function(sender, nodeId) {
            $('#delete-node-modal').show();
            $('#delete-node-confirm').click(function() {
                event.preventDefault();
                $.ajax({
                    type: 'DELETE',
                    url: "<?php echo e(URL('units')); ?>/" + nodeId,
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(dataResult) {
                        location.reload();
                        sender.removeNode(nodeId);
                        $('#delete-node-modal').hide();
                    }
                });
            });
            $('#delete-node-cancel').click(function() {
                $('#delete-node-modal').hide();
            });
        });

        var app = <?php echo json_encode($units, 15, 512) ?>;
        console.log(app);
        chart.load(app);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/units/index.blade.php ENDPATH**/ ?>