<?php $__env->startSection('main-section'); ?>
    <style>
        .mmt:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            background-image: url(images/logo.jpg);
            background-size: 500px;
            background-position: center;
            background-repeat: no-repeat;
            width: 100%;
            height: 100%;
            opacity: .1;
            z-index: 2;
        }
    </style>
    <!--Section Search  Staff Members-->
    <section class=" search-Wrapper mmt">
        <div class="container sw ">
            <div class="row  ">
                <div class="col-3   align-self-center "> <a href="Home.html"><i class="fa-solid fa-arrow-left"></i></a></div>
                <div class="col   text-left  align-self-center  ">
                    <h1>Search Notification</h1>
                </div>
            </div>
            <form action="" method="get" class="mt-2">
                <input type="text" name="q" placeholder="Enter Name/ID/Destination....">
                <button type="submit"><i class="fa-solid fa-magnifying-glass "></i></button>
            </form>
            
        </div>
    </section>
    <!--secton Search  Staff Members end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/admin/SearchNotification.blade.php ENDPATH**/ ?>