<?php $__env->startSection('main-section'); ?>
    <section class="Access-Wrapper">
        <div class="container aw ">
            <div class="row  ">
                <div class="col-3  align-self-center "> <a href="Search Staff Member.html"> <i
                            class="fa-solid fa-arrow-left"></i></a></div>
                <div class="col   text-left  align-self-center  ">
                    <h1>Access of Member</h1>
                </div>
                <div>
                    <div class="row ms-3">
                        <div class="col-5"> Name</div>
                        <div class="col-7">Admin</div>
                    </div>
                    <div class="row ms-3">
                        <div class="col-5">Name</div>
                        <div class="col">Admin</div>
                        <div class="col "><a class="text-decoration-none" href=""> View Profile</a></div>
                    </div>
                    <div class=" row mt-3">
                        <div class="col text-bold offset-2">Access:</div>
                    </div>
                    <!-- <div class="row mt-3 ">
                <div class="col offset-2 ">
                    <ul class="list-group  ">
                        <li class="list-group-item border-0 ps-3 "> <i class='fas fa-file-pdf me-2'
                              ></i> Summer Holidays Notification 2022</li>
                        <li class="list-group-item border-0  ps-3"> <i class='fas fa-file-pdf me-2'
                                ></i>Industrial Tour Mechnical 2019</li>
                    </ul>
                </div>
            </div> -->
                    <form action="/action_page.php" class="was-validated m-auto w-75">
                        <div class="mb-3 mt-3  ">

                            <input type="text" class="form-control   " id="tmd"
                                placeholder="To All Staff of Mechanical Department" name="tmd" required>
                            <div class="valid-feedback">Valid.</div>

                        </div>
                        <div class="mb-3">

                            <input type="text" class="form-control  " id="tdb" placeholder="To Admin Block"
                                name="tdb" required>
                            <div class="valid-feedback">Valid.</div>

                        </div>
                        <div class="mb-3">

                            <input type="text" class="form-control  " id="tt" placeholder="To Treasurer"
                                name="tt" required>
                            <div class="valid-feedback">Valid.</div>

                        </div>

                    </form>

                </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/admin/AccessMember.blade.php ENDPATH**/ ?>