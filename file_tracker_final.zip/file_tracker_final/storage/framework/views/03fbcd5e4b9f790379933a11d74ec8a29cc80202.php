<?php $__env->startSection('main-section'); ?>
    <div>
        <form action="<?php echo e(route('document.update', ['id' => $document->id])); ?>" class="was-validated m-auto w-75" method="post"
            enctype="multipart/form-data">
            <div>
                <h1 class="text-center my-5">Start New Document</h1>
                <div class="mb-3">
                    <input type="text" class="form-control" id="tdb" placeholder="Title of Document" name="title"
                        value="<?php echo e($document->title); ?>" required>
                </div>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <textarea type="text" class="form-control" id="tt" placeholder="Description or brief information for document"
                        name="description" required><?php echo $document->description; ?></textarea>
                </div>
                <div class="mb-3">
                    <input type="file" class="form-control" id="tdb" name="file" placeholder="Title of Document"
                        name="tdb">
                </div>
                <div class="mb-3">
                    <center>
                        <input type="submit" class="btn main-btn" value="Submit">
                    </center>
                </div>
            </div>
        </form>
    </div>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('tt');
        var content = CKEDITOR.instances.editor.getData();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hamid\Documents\University\FYP\file_tracker_Fullnfinal\file_tracker_final\resources\views/documents/edit.blade.php ENDPATH**/ ?>