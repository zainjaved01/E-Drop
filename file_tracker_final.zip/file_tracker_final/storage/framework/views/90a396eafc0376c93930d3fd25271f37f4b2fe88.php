<?php $__env->startSection('main-section'); ?>
    <section class="Mdetail-Wrapper mx-4 px-3">
        <h3 class="my-5 text-danger"><?php echo e($document->title); ?></h3>
        <div class="mb-3 mx-4 px-3">
            <?php echo $document->description; ?>

        </div>
        <?php if($document->file): ?>
            <?php if(str_ends_with($document->file, 'png') ||
                    str_ends_with($document->file, 'jpg') ||
                    str_ends_with($document->file, 'jpeg')): ?>
                <img src="<?php echo e(asset( $document->file)); ?>" alt="Image">
            <?php else: ?>
                <iframe width="800px" height="300px" src="<?php echo e(asset($document->file)); ?>"
                    frameborder="0"></iframe>
            <?php endif; ?>
        <?php endif; ?>
        <div class="mb-3 mx-4 px-3">
            <p class="text-center my-5"></p>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/documents/show.blade.php ENDPATH**/ ?>