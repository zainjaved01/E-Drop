<?php $__env->startSection('main-section'); ?>
    <!--Section Search  Staff Members-->
    <section class=" search-Wrapper mmt">
        <div class="container sw">
            <div class="row">
                <div class="col   text-left  align-self-center  ">
                    <h1>Search Document</h1>
                </div>
            </div>
            <form action="" method="get" class="mt-2">
                <input type="text" name="q" value="<?php echo e($q ? $q : ''); ?>" placeholder="Document title keywords">
                <button type="submit"><i class="fa-solid fa-magnifying-glass "></i></button>
            </form>
            <div class="row">
                <?php if($documents): ?>
                <div class="col ml-3 mt-5" >
                    <p>Results:</p>
                    <ul class="list-group  ">
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('document.show', ['id' => $document->document->id])); ?>"  class="list-group-item"><i class="fas fa-file-pdf me-2" ></i><?php echo e($document->document->title); ?></a></ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                </div>
        
                <?php endif; ?>
      </div>
        </div>
    </section>
    <!--secton Search  Staff Members end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/admin/search-documents.blade.php ENDPATH**/ ?>