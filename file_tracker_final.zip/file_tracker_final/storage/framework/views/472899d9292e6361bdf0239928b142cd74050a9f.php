<?php $__env->startSection('main-section'); ?>
    <section class="Mdetail-Wrapper">
        <div class="container">
            <h2 class="mb-">Manage Documents</h2>
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item document" data-document-id="<?php echo e($document->document->id); ?>"
                    data-document-name="<?php echo e($document->document->title); ?>">
                    <a href="<?php echo e(route('manage-document.show', ['id' => $document->document->id])); ?>"><i
                            class="fas fa-file-pdf  me-2"></i><?php echo e($document->document->title); ?>

                    </a>
                    <?php if(!($document->team_id || $document->next_id)): ?>
                    <p style="font-size: 12px;" class="text-success">Broad cast document</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker_final/resources/views/documents/manage-documents/index.blade.php ENDPATH**/ ?>