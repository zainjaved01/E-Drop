<?php $__env->startSection('main-section'); ?>
    <style>
        .list-group-item {
            border: 0;
        }
    </style>
    <section class=" notification-Wrapper">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <h1> Notifications</h1>
                </div>
            </div>
        </div>
        </div>
        <div class="container mt-4 ">
            <div class="row mt-3 ">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mx-3">
                        <?php if($notification->action == 'Forward'): ?>
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary"><?php echo e($notification->previous->name); ?></span>
                                    forwarded <?php echo e($notification->document->title); ?> to <?php if($notification->team): ?>
                                        <?php echo e($notification->team->name); ?> <?php else: ?>
                                        <?php echo e($notification->next->name); ?>

                                    <?php endif; ?>, <span
                                        class="text-dark"><?php echo e(date('F j, g:i a', strtotime($notification->created_at))); ?></span></a>
                            </ul>
                            <?php elseif($notification->action == 'Complete'): ?>
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary"><?php echo e($notification->previous->name); ?></span>
                                    marked <?php echo e($notification->document->title); ?> as completed. <span
                                        class="text-dark"><?php echo e(date('F j, g:i a', strtotime($notification->created_at))); ?></span></a>
                            </ul>
                            <?php elseif($notification->action == 'Duplicate'): ?>
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary"><?php echo e($notification->previous->name); ?></span>
                                    marked <?php echo e($notification->document->title); ?> as duplicate. <span
                                        class="text-dark"><?php echo e(date('F j, g:i a', strtotime($notification->created_at))); ?></span></a>
                            </ul>
                            <?php elseif($notification->action == 'Decline'): ?>
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary"><?php echo e($notification->previous->name); ?></span>
                                    declined <?php echo e($notification->document->title); ?>. <span
                                        class="text-dark"><?php echo e(date('F j, g:i a', strtotime($notification->created_at))); ?></span></a>
                            </ul>
                            <?php elseif($notification->action == 'Initiated'): ?>
                            <ul class="list-group mb-1 pb-1">
                                <a class="list-group-item  "><i class="fas fa-file-pdf me-2"></i><span
                                        class="text-primary"><?php echo e($notification->previous->name); ?></span>
                                        initiated <?php echo e($notification->document->title); ?>. <span
                                        class="text-dark"><?php echo e(date('F j, g:i a', strtotime($notification->created_at))); ?></span></a>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/admin/notifications.blade.php ENDPATH**/ ?>