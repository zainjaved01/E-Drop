<?php $__env->startSection('main-section'); ?>
    <div>
        <form action="<?php echo e(route('document.store')); ?>" class=" m-auto w-75" method="post" enctype="multipart/form-data">
            <div>
                <h1 class="text-center my-5">Start New Document</h1>
                <div class="mb-3">
                    <input type="text" class="form-control" id="tdb" placeholder="Title of Document" name="title"
                        required>
                </div>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <textarea type="text" class="form-control" id="tt" placeholder="Description or brief information for document"
                        name="description" required></textarea>
                    <div class="valid-feedback">Valid.</div>
                </div>
                <div class="mb-3">
                    <input type="file" class="form-control" id="tdb" name="file" placeholder="Title of Document"
                        name="tdb">
                </div>
                <div>
                    <p class="mb-1 mt-4"> Forword document to </p>
                    <div class="mb-2">
                        <label class="mr-3">
                            <input type="radio" name="targetType" value="user" checked>
                            User
                        </label>
                        <label class="mx-3">
                            <input type="radio" name="targetType" value="team">
                            Team
                        </label>
                        <?php if(auth()->user()->isSuperAdmin()): ?>
                            <label>
                                <input type="radio" name="targetType" value="all">
                                All
                            </label>
                        <?php endif; ?>
                    </div>

                    <div id="team-input" style="display:none">
                        <label>
                            <select class="select2" name="team">
                                <option>Select Team</option>
                                <?php $__currentLoopData = $teamUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <div id="user-input">
                        <label>
                            <select class="select3" name="person">
                                <option>Select User</option>
                                <?php $__currentLoopData = $userUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                </div>
                <div class="mb-3">
                    <center>
                        <input type="submit" class="btn main-btn" value="Submit">
                    </center>
                </div>
            </div>
        </form>
    </div>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        const teamInput = document.querySelector('#team-input');
        const userInput = document.querySelector('#user-input');

        document.querySelectorAll('input[name="targetType"]').forEach((radio) => {
            radio.addEventListener('change', () => {
                if (radio.value === 'team') {
                    teamInput.style.display = 'block';
                    userInput.style.display = 'none';
                } else if (radio.value === 'user') {
                    teamInput.style.display = 'none';
                    userInput.style.display = 'block';
                } else if (radio.value === 'all') {
                    teamInput.style.display = 'none';
                    userInput.style.display = 'none';
                }
            });
        });

        CKEDITOR.replace('tt');
        var content = CKEDITOR.instances.editor.getData();

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hamid\Documents\University\FYP\file_tracker_Fullnfinal\file_tracker_final\resources\views/documents/create.blade.php ENDPATH**/ ?>