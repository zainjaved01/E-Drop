<?php $__env->startSection('main-section'); ?>
    <!--Section Search  Staff Members-->
    <section class=" smm-wrapper">
        <div class="notification-Wrapper">
            <div class="container  ">
                <div class="row  ">
                    <div class="col   text-left  align-self-center  ">
                        <h1>Search/Manage units</h1>
                    </div>
                </div>
                
            </div>
            <div class="container">
                <a class="list-group-item list-group-item-action border-0" style="margin-left: 80px" href="/units"><i
                    class="fa fa-sitemap fa-xl fa-xl"></i><span> Use Graph</span></a>
                <div class="row  mt-4">
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4 d-flex justify-content-center">
                            <a href="<?php echo e(route('manage-unit', [ 'id' => $unit->id ])); ?>">
                            <div class="card" style="">
                                <div class="card-body">
                                    <div class="row d-flex justify-content-center align-items-center mt-3 text-center">
                                        <div class="col text-start"><?php echo e($unit->name); ?> <br> <?php echo e($unit->type); ?></div>
                                        <div class="col"> <i class="fa-solid fa-user"></i></div>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>

    </section>
    <!--secton Search  Staff Members end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kaleem/workspace/document-tracking/file_tracker/resources/views/admin/manage-units.blade.php ENDPATH**/ ?>