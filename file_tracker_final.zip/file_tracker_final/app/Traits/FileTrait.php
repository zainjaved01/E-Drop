<?php

namespace App\Traits;

use Illuminate\Support\Facades\Storage;

trait FileTrait
{
    public static function saveFile($file, $path, $oldpath = null)
    {
        if ($oldpath != null){
            Storage::delete($oldpath);
        }
        $randomize = rand(111111, 999999);
        $filename =  $randomize . time() . '.' . $file->getClientOriginalExtension();
        $filePath = $file->storeAs($path, $filename , 'public' );
        return $filePath;
    }
}
