<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Facades\Config;
use Mpociot\Teamwork\TeamworkTeam;

class Team extends TeamworkTeam
{
    /**
     * Many-to-Many relations with the user model.
     *
     * @return BelongsToMany
     */
    // public function usersWithoutOwner(): BelongsToMany
    // {
    //     return $this->belongsToMany(Config::get('teamwork.user_model'), Config::get('teamwork.team_user_table'), 'team_id', 'user_id')->where('user_id', '!=', $this->owner_id)->withTimestamps();
    // }

    // public function clients(): BelongsToMany
    // {
    //     return $this->belongsToMany(Config::get('teamwork.user_model'), Config::get('teamwork.team_user_table'), 'team_id', 'user_id');
    // }
    // public function subUsers(): BelongsToMany
    // {
    //     return $this->belongsToMany(Config::get('teamwork.user_model'), Config::get('teamwork.team_user_table'), 'team_id', 'user_id')->whereHas('roles', function ($query) {
    //         return $query->where('name', 'sub-user');
    //     })->withTimestamps();
    // }
}
