<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Document extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'description',
        'status',
        'user_id',
        'file',
    ];


    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function DocumentHistories()
    {
        return $this->hasMany(DocumentHistory::class);
    }
    
    public function getFileAttribute($value)
    {
        return 'storage/' . $value;
    }
}
