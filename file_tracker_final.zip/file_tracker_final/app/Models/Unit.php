<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function parent()
    {
        return $this->belongsTo(Unit::class, 'pid');
    }


    public function responder()
    {
        return $this->belongsTo(User::class, 'responder_id');
    }

    public function children()
    {
        return $this->hasMany(Unit::class, 'pid');
    }

    public function team()
    {
        return $this->belongsTo(Team::class);
    }
}
