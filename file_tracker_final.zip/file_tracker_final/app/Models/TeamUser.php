<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;

class TeamUser extends Model
{
    use HasFactory, HasRoles;

    protected $table = 'team_user';
    protected $guard_name = 'web';

    // public static function assignRoleToTeamUser($user_id, $team_id, $role)
    // {
    //     $teamUser = self::where([['user_id', $user_id], ['team_id', $team_id]])->first();
    //     $teamUser->assignRole($role);
    // }
}