<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentHistory extends Model
{
    use HasFactory;

    protected $fillable = [
        'document_id',
        'team_id',
        'next_id',
        'previous_id',
        'action',
        'remarks',
    ];

    public function document()
    {
        return $this->belongsTo(Document::class);
    }

    public function team()
    {
        return $this->belongsTo(Team::class);
    }

    public function next()
    {
        return $this->belongsTo(User::class, 'next_id');
    }

    public function previous()
    {
        return $this->belongsTo(User::class, 'previous_id');
    }

    // public function origin()
    // {
    //     return $this->belongsTo(User::class, 'previous_id');
    // }
}
