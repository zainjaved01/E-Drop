<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\DocumentHistory;
use App\Models\Unit;
use App\Models\User;
use App\Models\Team;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;


class ManageDocumentController extends Controller
{
    public function index()
    {
        $subquery = DocumentHistory::select('document_id', DB::raw('MAX(created_at) as max_created_at'))
            ->groupBy('document_id');

        $documents = DocumentHistory::joinSub($subquery, 'latest_histories', function ($join) {
            $join->on('document_histories.document_id', '=', 'latest_histories.document_id')
                ->on('document_histories.created_at', '=', 'latest_histories.max_created_at');
        });
        $team = auth()->user()->currentTeam;
        $documents = $documents->where('next_id', auth()->user()->id);
        if ($team && $team->owner->id == Auth::id()) {
            $documents = $documents->orWhere('team_id', auth()->user()->currentTeam->id);
        }

        if($team && Unit::where('team_id',$team->id)->first()->responder_id == Auth::id()){
            $documents = $documents->orWhere('team_id', $team->id);
        }

        $documents = $documents
            ->where('responded', 0)
            ->with([
                'document',
                'next',
                'previous',
                'team'
            ])->get();
        $broadcastDocuments = DocumentHistory::whereNull('next_id')->whereNull('team_id')
            ->with([
                'document',
                'next',
                'previous',
                'team'
            ])->get();

        $documents = $documents->concat($broadcastDocuments);

        $userUnits = Unit::whereNull('team_id')->get();
        $teamUnits = Unit::whereNotNull('team_id')->get();

        return view('documents.manage-documents.index', compact('documents', 'userUnits', 'teamUnits'));
    }

    public function store(Request $request)
    {
        $documentHistory = DocumentHistory::where('document_id', $request->documentId)->first();
        if ($request->submit == "Complete") {
            $documentHistoryNext = DocumentHistory::create([
                'document_id' => $documentHistory->document_id,
                'team_id' => $documentHistory->team_id,
                'next_id' => $documentHistory->document->user_id,
                'previous_id' => auth()->user()->id,
                'action' => 'Complete',
                'remarks' => $request->remarks,
            ]);
        } elseif ($request->submit == "Forward") {
            $team = null;
            if ($request->targetType == 'team' && $request->team) {
                $team = Team::where('id', $request->team)->first();
            } elseif ($request->targetType == 'user' && $request->person) {
                $user = User::where('id', $request->person)->first();
            }

            $documentHistoryNext = DocumentHistory::create([
                'document_id' => $documentHistory->document_id,
                'team_id' => $team ? $team->id : null,
                'previous_id' => Auth::id(),
                'next_id' => $request->targetType == 'user' && $user ? $user->id : $team->owner_id,
                'action' => 'Forward',
                'remarks' => $request->remarks,
            ]);
        } elseif ($request->submit == "Duplicate") {
            $documentHistoryNext = DocumentHistory::create([
                'document_id' => $documentHistory->document_id,
                'team_id' => $documentHistory->team_id,
                'next_id' => $documentHistory->document->user_id,
                'previous_id' => auth()->user()->id,
                'action' => 'Duplicate',
                'remarks' => $request->remarks,
            ]);
        } else {
            $documentHistoryNext = DocumentHistory::create([
                'document_id' => $documentHistory->document_id,
                'team_id' => $documentHistory->team_id,
                'next_id' => $documentHistory->document->user_id,
                'previous_id' => auth()->user()->id,
                'action' => 'Decline',
                'remarks' => $request->remarks,
            ]);
        }

        $documentHistory->responded = true;
        $documentHistory->save();

        return redirect()->back();
    }

    public function edit(Request $request, $id)
    {
        $document = Document::find($id);
        return redirect()->back();
    }

    public function update(Request $request, $id)
    {
        $document = Document::where('id', $id)
            ->where('user_id', auth()->user()->id)->first();

        $document->update([
            'title' => $request->title,
            'description' => $request->description,
            'user_id' => Auth::user()->id,
        ]);

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $fileName = time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/documents', $fileName);
            $document->file = $fileName;
        }

        return redirect()->route('document.show', ['id' => $document->id]);
    }

    public function show(Request $request, $id)
    {
        $document = Document::where('id', $id)->with('DocumentHistories')->first();
        $userUnits = User::all();
        $teamUnits = Team::all();
        return view('documents.manage-documents.show',compact(['userUnits', 'teamUnits','document']));
    }
}
