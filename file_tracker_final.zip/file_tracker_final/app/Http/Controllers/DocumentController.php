<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\DocumentHistory;
use App\Models\Team;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Traits\FileTrait;

class DocumentController extends Controller
{
 
    use FileTrait;

    public function index()
    {
        $documents = Document::where('user_id', auth()->user()->id)->get();
        return view('documents.index', compact('documents'));
    }

    public function create()
    {
        $userUnits = User::all();
        $teamUnits = Team::all();
        return view('documents.create', compact(['userUnits', 'teamUnits']));
    }

    public function store(Request $request)
    {
        $document = Document::create([
            'title' => $request->title,
            'description' => $request->description,
            'user_id' => Auth::user()->id,
        ]);

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filePath = $this->saveFile($file, 'documents/files');
            $document->file = $filePath;
        }

        $document->save();
        $data = $request->all();
        $team = null;
        if ($request->targetType == 'team') {
            $team = Team::find($data['team']);
        }elseif($request->targetType == 'user'){
            $user = User::find($request->person);
        }elseif($request->targetType == 'all'){
            $unit = null;
        }
        
        $documentHistory = DocumentHistory::create([
            'document_id' => $document->id,
            'team_id' => $team ? $team->id : null,
            'previous_id' => Auth::id(),
            'next_id' => $request->targetType == 'user' && $user ? $user->id : ($team ? $team->owner_id : null),
            'action' => 'Initiated',
            'remarks' => null,
        ]);

        return redirect()->route('document.show', ['id' => $document->id]);
    }

    public function edit(Request $request, $id)
    {
        $document = Document::find($id);
        return view('documents.edit', compact('document'));
    }

    public function update(Request $request, $id)
    {
        $document = Document::where('id', $id)
            ->where('user_id', auth()->user()->id)->first();

        $document->update([
            'title' => $request->title,
            'description' => $request->description,
        ]);

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filePath = $this->saveFile($file, 'documents/files');
            $document->file = $filePath;
        }

        return redirect()->route('document.show', ['id' => $document->id]);
    }

    public function show(Request $request, $id)
    {
        $document = Document::find($id);
        return view('documents.show', compact('document'));
    }
}
