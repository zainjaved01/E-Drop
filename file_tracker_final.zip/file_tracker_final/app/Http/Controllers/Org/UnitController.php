<?php

namespace App\Http\Controllers\Org;


use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Unit;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UnitController extends Controller
{
    public function index()
    {
        $userUnits = User::all();
        $units = Unit::with(['user', 'team'])->get();
        return view('units.index', ['units' => $units, 'userUnits' => $userUnits]);
    }
    public function store(Request $request)
    {
        $user = User::where('email', $request->semail)->first();
        if (!$user && ($request->username && $request->password && $request->email)) {
            $user = User::create([
                'name' => $request->username,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
            event(new Registered($user));
        }

        $type = $request->type;

        if ($request->team && $type == 'team') {
            $team = Team::create([
                'name' => $request->team,
                'owner_id' => $user->id
            ]);
            $user->attachTeam($team);
        }

        Unit::create([
            'name' => $request->name,
            'pid' => $request->pid,
            'type' => $type,
            'user_id' => $user->id,
            'responder_id' => $user->id,
            'team_id' => $type == 'team' && $team ? $team->id : null,
        ]);
        return redirect()->route('units.index')
            ->with('success', 'Unit created successfully.');
    }


    public function update(Request $request)
    {
        $user = User::where('email', $request->semail)->first();
        if (!$user && ($request->username && $request->password && $request->email)) {
            $user = User::create([
                'name' => $request->username,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
            event(new Registered($user));
        }

        $type = $request->type;

        if ($request->team && $type == 'team') {
            $team = Team::create([
                'name' => $request->team,
                'owner_id' => $user->id
            ]);
            $user->attachTeam($team);
        }
        Unit::create([
            'name' => $request->name,
            'pid' => $request->pid,
            'type' => $type,
            'user_id' => $user->id,
            'team_id' => $type == 'team' && $team ? $team->id : null,
        ]);
        Auth::login($user);
        return redirect()->route('units.index')
            ->with('success', 'Unit created successfully.');
    }
    public function destroy($id)
    {

        Unit::find($id)->delete();

        return json_encode(array('statusCode' => 200));
    }
}
